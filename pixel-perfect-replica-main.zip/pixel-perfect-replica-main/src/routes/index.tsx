import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "YNEX OPTIMIZATIONS — Desbloqueie Seu Potencial" },
      { name: "description", content: "YNEX Optimizations: otimizações para desbloquear o máximo desempenho do seu PC." },
      { property: "og:title", content: "YNEX OPTIMIZATIONS" },
      { property: "og:description", content: "Otimizações para desbloquear o máximo desempenho do seu PC." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/site.html"
      title="YNEX Optimizations"
      className="fixed inset-0 h-screen w-screen border-0"
    />
  );
}
